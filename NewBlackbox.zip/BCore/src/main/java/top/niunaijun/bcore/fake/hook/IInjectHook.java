package top.niunaijun.bcore.fake.hook;

public interface IInjectHook {
    void injectHook();

    boolean isBadEnv();
}
