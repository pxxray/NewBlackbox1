package top.niunaijun.bcore.core.system;

public interface ISystemService {
    void systemReady();
}
