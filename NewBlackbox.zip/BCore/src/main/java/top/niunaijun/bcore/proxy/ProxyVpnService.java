package top.niunaijun.bcore.proxy;

import android.net.VpnService;

public class ProxyVpnService extends VpnService { }
